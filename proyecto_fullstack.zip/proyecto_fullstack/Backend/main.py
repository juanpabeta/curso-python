from fastapi import FastAPI, HTTPException, Depends,Query
from sqlalchemy.orm import Session
from models.user import Usuario
from schemas.user import UsuarioCreate,UsuarioResponse
from db.db import get_db 
from sqlalchemy import or_
from typing import List
from fastapi.middleware.cors import CORSMiddleware

app = FastAPI()

puerto = [
    "http://localhost:5173",  
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=puerto,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.post("/api/usuarios", response_model=UsuarioResponse)
def crear_usuario(usuario: UsuarioCreate, db: Session = Depends(get_db)):

    usuario_existente = db.query(Usuario).filter(Usuario.email == usuario.email).first()
    
    if usuario_existente:
        raise HTTPException(status_code=400, detail="El correo electrónico ya está registrado")
    
    nuevo_usuario =Usuario(
        nombre_completo=usuario.nombre_completo, 
        email=usuario.email
    )
    db.add(nuevo_usuario)
    db.commit()
    db.refresh(nuevo_usuario)
    
    return nuevo_usuario


@app.get("/api/usuarios", response_model=List[UsuarioResponse])
def obtener_usuarios(
    db: Session = Depends(get_db),
    page: int = Query(1, ge=1, description="Número de página"),
    limit: int = Query(10, ge=1, description="Cantidad de registros por página"),
    search: str | None = Query(None, description="Búsqueda por nombre o email")
):
    query = db.query(Usuario)

    if search:
        query = query.filter(
            or_(
                Usuario.nombre_completo.ilike(f"%{search}%"),
                Usuario.email.ilike(f"%{search}%")
            )
        )
    skip = (page - 1) * limit
    usuarios = query.offset(skip).limit(limit).all()

    if search and not usuarios:
        raise HTTPException(status_code=404, detail="El usuario no se encuentra")

    return usuarios

@app.delete("/api/usuarios/{id}")
def eliminar_usuario(id: int, db: Session = Depends(get_db)):
    usuario_existente = db.query(Usuario).filter(Usuario.id == id).first()
    
    if not usuario_existente:
        raise HTTPException(status_code=404, detail="Usuario no encontrado")
    
    db.delete(usuario_existente)
    db.commit()
    
    return {"mensaje": "Usuario eliminado correctamente"}